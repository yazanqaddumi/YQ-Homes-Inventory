-- YQ Homes Inc. Stock: run this ONCE in Supabase SQL Editor
create table if not exists public.stock_items (
  user_id uuid not null references auth.users(id) on delete cascade,
  id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id,id)
);
alter table public.stock_items enable row level security;
drop policy if exists "Users read own stock" on public.stock_items;
drop policy if exists "Users add own stock" on public.stock_items;
drop policy if exists "Users edit own stock" on public.stock_items;
drop policy if exists "Users delete own stock" on public.stock_items;
create policy "Users read own stock" on public.stock_items for select to authenticated using (auth.uid() = user_id);
create policy "Users add own stock" on public.stock_items for insert to authenticated with check (auth.uid() = user_id);
create policy "Users edit own stock" on public.stock_items for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users delete own stock" on public.stock_items for delete to authenticated using (auth.uid() = user_id);
grant select,insert,update,delete on public.stock_items to authenticated;
-- Atomic increment/decrement to avoid losing rapid adjustments from two devices.
create or replace function public.adjust_stock(p_id text, p_delta numeric)
returns jsonb language plpgsql security invoker set search_path = public as $$
declare v_data jsonb; v_quantity numeric;
begin
  select data into v_data from public.stock_items where user_id=auth.uid() and id=p_id for update;
  if not found then raise exception 'Item not found'; end if;
  v_quantity := greatest(0,coalesce((v_data->>'quantity')::numeric,0)+p_delta);
  v_data := jsonb_set(v_data,'{quantity}',to_jsonb(v_quantity),true);
  update public.stock_items set data=v_data,updated_at=now() where user_id=auth.uid() and id=p_id;
  return v_data;
end $$;
revoke all on function public.adjust_stock(text,numeric) from public,anon;
grant execute on function public.adjust_stock(text,numeric) to authenticated;
